
//1
function selecttal() {
    let antal = 31
    let tallet = 1;
    document.body.innerHTML += `<h4>Tal</h4><select id="tal"></select > `
    for (i = 0; i < antal; i++) {
        document.querySelector('#tal').innerHTML += `<option value="` + tallet + `">` + tallet + `</option>`
        tallet++;
    }
}
selecttal()
//2
function month() {

    let month = ['januar', 'februar', 'marts', 'april', 'maj', 'juni', 'juli', 'august', 'september', 'oktober', 'november', 'december']
    document.body.innerHTML += `<h4>måneder</h4><select id="month"></select > `
    for (i = 0; i < month.length; i++) {
        document.querySelector('#month').innerHTML += `<option value="` + [i] + `">` + month[i] + `</option>`
    }
}
month()
//3
function aar() {
    let antal = 30
    let aar = 2018

    document.body.innerHTML += `<h4>år</h4><select id="aar"></select > `
    for (i = 0; i < antal; i++) {
        document.querySelector('#aar').innerHTML += `<option value="` + aar + `">` + aar + `</option>`
        aar = aar - 1
    }
}
aar()