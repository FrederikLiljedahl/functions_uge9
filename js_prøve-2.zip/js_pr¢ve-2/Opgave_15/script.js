var computer = Math.floor(Math.random() * 100 - 1) + 1

var bruger = document.querySelector('#guess');
var turns = 0
document.querySelector('.tjek').addEventListener('click', function (event) {
    event.preventDefault();

    if (bruger.value <= 100 && bruger.value != 0) {
        if (bruger.value == computer) {
            turns++;
            document.querySelector('#main').innerHTML = "Rigtigt, du brugte " + turns + " forsøg <a href='index.html'>Genstart</a><img src='picture.jpg' style='display:block;' height='400px' width='400px'>"
        } else {
            if (computer <= bruger.value) {
                turns++;
                if (turns == 10) {
                    alert('Forkert du har tabt, tallet var ' + computer)
                    window.location.reload(true);
                } else {
                    alert("forkert, tallet er mindre, du har brugt " + turns);
                }
            } else if (computer >= bruger.value) {
                turns++;
                if (turns == 10) {
                    alert('Forkert du har tabt, tallet var ' + computer)
                    window.location.reload(true);
                } else {
                    alert("forkert, tallet er større, du har brugt " + turns);
                }
            }
        }
    } else {
        alert('brug gyldig tal melllem 1-100')
    }

});

