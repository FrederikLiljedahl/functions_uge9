//1
let json = { "fornavn": "Jimi", "efternavn": "Hendrix" }

let div = document.createElement('div')
div.setAttribute('class', 'json')
let h3 = document.createElement('h3')
let h3txt = document.createTextNode(json.fornavn + " " + json.efternavn)
h3.appendChild(h3txt)
document.body.appendChild(div)
document.querySelector('.json').appendChild(h3)

