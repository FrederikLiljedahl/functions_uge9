//1
let heltal = 1
console.log(heltal)

//3
let dato = Date()
console.log(dato)

//4
let ok = true
console.log(ok)
