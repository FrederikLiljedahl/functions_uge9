function hentAreal(højde, bredde) {
    let areal = højde * bredde
    let p = document.createElement('p')
    let ptxt = document.createTextNode("Arealet er: " + areal)
    p.appendChild(ptxt)
    document.body.appendChild(p)
}

hentAreal(3, 2)
