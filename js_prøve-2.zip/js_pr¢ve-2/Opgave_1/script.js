function sammenlign(tekst1, tekst2) {

    if (tekst1 === tekst2) {
        alert('rigtigt')
    } else {
        alert('forkert')
    }

}


document.querySelector('#tjek').addEventListener('click', function (event) {
    let tekst1 = document.querySelector('#tekst1').value
    let tekst2 = document.querySelector('#tekst2').value
    sammenlign(tekst1, tekst2)
});

