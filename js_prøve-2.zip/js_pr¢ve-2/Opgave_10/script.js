let tal = 0
if (tal == 1) {
    let tjek = null
}
console.log(tjek)