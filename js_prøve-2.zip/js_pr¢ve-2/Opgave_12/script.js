var turn = 0
document.querySelector('#a').addEventListener('click', function (event) {
    document.querySelector('#a').style.display = "none"

    if (document.querySelector('#c').style.display === "none") {
        turn++;
        tjek()
    } else {
        tjek()
    }

});
document.querySelector('#b').addEventListener('click', function (event) {
    document.querySelector('#b').style.display = "none"

    if (document.querySelector('#a').style.display === "none") {
        turn++;
        tjek()
    } else {
        tjek()
    }
});
document.querySelector('#c').addEventListener('click', function (event) {
    document.querySelector('#c').style.display = "none"
    turn++;
    tjek()
});

function tjek() {
    if (turn === 3) {
        alert('Godt klaret')
    } else if (document.querySelector('#a').style.display === "none" &&
        document.querySelector('#b').style.display === "none" &&
        document.querySelector('#c').style.display === "none") {
        alert('forkert røkkefølge')
    }
}