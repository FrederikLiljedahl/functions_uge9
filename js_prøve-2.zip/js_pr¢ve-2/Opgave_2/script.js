function adresselabel(fornavn, efternavn, vej, husnummer, postnummer, bynavn) {
    let p = document.createElement('p')
    let ptxt = document.createTextNode("Adresselabel: " + fornavn + " " + efternavn + ", " + vej + " " + husnummer + " " + postnummer + " " + bynavn)
    p.appendChild(ptxt)
    document.body.appendChild(p)
}

adresselabel('Frederik', 'Liljedahl', 'pulsen', '8', '4000', 'roskilde')