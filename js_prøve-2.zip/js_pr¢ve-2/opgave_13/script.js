document.querySelector('#side2fraside1').addEventListener('click', function () {
    document.querySelector('#side1').style.display = "block"
    document.querySelector('#side2').style.display = "block"
    document.querySelector('#side3').style.display = "block"
    document.querySelector('#side1').style.display = "none"
    document.querySelector('#side3').style.display = "none"
})

document.querySelector('#side1fraside2').addEventListener('click', function () {
    document.querySelector('#side1').style.display = "block"
    document.querySelector('#side2').style.display = "block"
    document.querySelector('#side3').style.display = "block"
    document.querySelector('#side2').style.display = "none"
    document.querySelector('#side3').style.display = "none"
})

document.querySelector('#side3fraside2').addEventListener('click', function () {
    document.querySelector('#side1').style.display = "block"
    document.querySelector('#side2').style.display = "block"
    document.querySelector('#side3').style.display = "block"
    document.querySelector('#side1').style.display = "none"
    document.querySelector('#side2').style.display = "none"

})
document.querySelector('#side2fraside3').addEventListener('click', function () {
    document.querySelector('#side1').style.display = "block"
    document.querySelector('#side2').style.display = "block"
    document.querySelector('#side3').style.display = "block"
    document.querySelector('#side1').style.display = "none"
    document.querySelector('#side3').style.display = "none"

})

document.querySelector('#tjekside').addEventListener('click', function () {
    let fejl = '';
    let navnside1 = document.querySelector('#omdig_navn').value;
    let beskedside1 = document.querySelector('#omdig_besked').value;
    let navnside2 = document.querySelector('#omos_navn').value;
    let beskedside2 = document.querySelector('#omos_besked').value;
    let navnside3 = document.querySelector('#omarbejde_navn').value;
    let beskedside3 = document.querySelector('#omarbejde_besked').value;
    if (navnside1 === '') {
        fejl += "udfyld navn side 1 \n";
    }
    if (beskedside1 === '') {
        fejl += "udfyld besked side 1 \n";
    }
    if (navnside2 === '') {
        fejl += "udfyld navn side 2 \n";
    }
    if (beskedside2 === '') {
        fejl += "udfyld besked side 2 \n";
    }
    if (navnside3 === '') {
        fejl += "udfyld navn side 3 \n";
    }
    if (beskedside3 === '') {
        fejl += "udfyld besked side 3 ";
    }

    if (fejl === "") {
        alert('tak');
        tak()
    } else {
        alert(fejl);
        event.preventDefault();
    }
});

function tak() {
    document.write('tak for beskeden')

}




