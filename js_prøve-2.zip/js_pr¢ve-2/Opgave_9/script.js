var alder = 20
var besked = 'velkommen'

if (alder <= 17) {
    var besked = "Desværre, du er ikke gammel nok"
}

console.log(besked)