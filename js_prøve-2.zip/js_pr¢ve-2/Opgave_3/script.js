function prisMedMoms(pris) {
    let moms = pris * 1.25
    let p = document.createElement('p')
    let ptxt = document.createTextNode("Prisen uden moms er " + pris + " prisen med moms er " + moms)
    p.appendChild(ptxt)
    document.body.appendChild(p)
}

prisMedMoms(200)
prisMedMoms(800)