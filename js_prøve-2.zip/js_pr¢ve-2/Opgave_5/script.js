let ugedage = ['mandag', 'tirsdag', 'onsdag', 'torsdag', 'fredag', 'lørdag', 'søndag']

function forloop() {
    let h3 = document.createElement('h3')
    let h3txt = document.createTextNode("For løkke")
    h3.appendChild(h3txt)
    document.body.appendChild(h3)
    for (i = 0; i < ugedage.length; i++) {
        let p = document.createElement('p')
        let ptxt = document.createTextNode("Ugedage:" + ugedage[i])
        p.appendChild(ptxt)
        document.body.appendChild(p)
    }
}
forloop()

function foreach() {
    let h3 = document.createElement('h3')
    let h3txt = document.createTextNode("ForEach")
    h3.appendChild(h3txt)
    document.body.appendChild(h3)
    ugedage.forEach(function (indhold) {
        let p = document.createElement('p')
        let ptxt = document.createTextNode("Ugedage:" + indhold)
        p.appendChild(ptxt)
        document.body.appendChild(p)
    })

}
foreach()

