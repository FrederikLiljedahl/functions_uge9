document.querySelector('#log').addEventListener('click', function (event) {
    if (document.querySelector('#bruger').value === '123' && document.querySelector('#kode').value === '123') {
        event.preventDefault();
        loggedind()
    } else {
        alert('forkert brugernavn eller password')
    }
});

function loggedind() {
    document.querySelector('form').style.display = 'none';
    document.body.innerHTML += `<button id="logud">log ud</button>`
    document.querySelector('#logud').addEventListener('click', function (e) {
        location.reload();
    });

}
